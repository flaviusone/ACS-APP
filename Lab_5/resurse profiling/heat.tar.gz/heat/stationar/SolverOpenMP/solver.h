/* 
 * File:   solver.h
 * Author: Ana-Maria Tuleiu
 *
 * Created on July 19, 2008, 3:25 AM
 */

#ifndef _SOLVER_H
#define	_SOLVER_H
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>

#include <omp.h>

#define P_JACOBI                0
#define P_GAUSS_SEIDEL          1
#define P_GAUSS_SEIDEL_RELAX    2
#define MAX_STACK_SIZE	100


typedef struct scn
{
    int OMP_THREADS;
    int nx;
    int ny;
    double rx;
    double ry;
    int raza;
    double temp;
    int alg[3];
    double EPS;
    double beta;
    double h;
    double time[3];
    unsigned long MAX_ITER;
    char func[100];
} scenario_t;

typedef struct 
{
    char st[MAX_STACK_SIZE][10];
    int sp;
} stack_t;

// Global variables
scenario_t *scenario;
int num_scenarios, scn_index;
double EPS, beta, h;
unsigned long MAX_ITER;
int nx, ny;

// General use functions
double func (int i, int j, int nx, int ny, char* func_polish);
void print_mat(double **a, int nx, int ny);
void init(double **uc, double **ua, int nx, int ny, double **q, int rx, int ry, int raza, double temp);
void clear(double **uc, int nx, int ny);

// Import functions (data)
int import_data_file(char *path);

// Export functions (data & results)
int export_to_vtk(double **mat, int nx, int ny, int alg_type, int scn_index);
int export_to_gnuplot(int alg_type, int scn_index);

// Serial algorithms
double p_jacobi(double **uc, double **ua, double **q, double h, int nx, int ny);
double p_gauss_seidel(double **uc, double **q, double h, int nx, int ny);
double p_gauss_seidel_relax(double **uc, double beta, double **q, double h, int nx, int ny);

// Arithmetic expressions evaluation functions (for input data)
void init_stack(stack_t* stack);
int empty_stack(stack_t stack);
void push(stack_t* stack, char* x);
char* pop(stack_t* stack);
char* top(stack_t* stack);
char* reverse_polish_notation(char* in);
int priority(char* op);
double eval (char* in, double x, double y);
double calculate(double x, double y, char* op);
int is_operator(char* aux);

