/* 
 * File:   parse_func.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

#include "solver.h"

void init_stack (stack_t* stack)
{
	memset(stack, 0, sizeof(stack_t));
}

int empty_stack(stack_t stack)
{
	if(stack.sp > 0)
		return 0;
	return 1;
}

void push (stack_t* stack, char* x)
{
	if (stack->sp < MAX_STACK_SIZE - 1)
	{
		strcpy(stack->st[stack->sp],x);
		stack->sp++;
	}
}

char* pop (stack_t* stack)
{
	char* aux = (char*)calloc(10,sizeof(char));
	if(stack->sp > 0)
	{
		stack->sp--;
		strcpy(aux,stack->st[stack->sp]);
		memset(stack->st[stack->sp],0,10*sizeof(char));
	}
	return aux;
}

char* top (stack_t* stack)
{
	if(stack->sp > 0)
		return stack->st[stack->sp-1];
	return NULL;
}

int priority(char* op)
{
	if(!strcmp(op,"("))
		return 0;
	else if(!strcmp(op,"+"))
		return 1;
	else if(!strcmp(op,"-"))
		return 1;
	else if(!strcmp(op,"*"))
		return 2;
	else if(!strcmp(op,"/"))
		return 2;
	else if(!strcmp(op,"^"))
		return 3;
	return -1;
}

void print_stack(stack_t stack)
{
	int i = 0;
	printf("Continutul stivei [%d]: ",stack.sp);
	for(i=0;i<stack.sp;i++)
		printf("|%s| ",stack.st[i]);
	printf("\n\n");
}

char* reverse_polish_notation(char* in)
{
	stack_t stack;
	char* in_aux = (char*)calloc(100,sizeof(char));
	char *op = NULL;
	char* out = (char*)calloc(100,sizeof(char));

	init_stack(&stack);
	
	strcpy(in_aux,in);
	char* aux = strtok(in_aux," ");
	while(aux)
	{
		if(!strcmp(aux,"("))
			push(&stack,aux);
		else if(!strcmp(aux,")"))
		{
			op = pop(&stack);
			while(strcmp(op,"("))
			{
				strcat(out,op);
				strcat(out," ");
				op = pop(&stack);
			}
		}
		else if(is_operator(aux))
		{
			while(!empty_stack(stack) && (priority(aux) <= priority(top(&stack))))
			{
				op = pop(&stack);
				strcat(out,op);
				strcat(out," ");
			}
			push(&stack,aux);
		}
		else
		{
			strcat(out,aux);
			strcat(out," ");
		}
		aux = strtok(NULL," ");
	}
	
	while(!empty_stack(stack))
	{
		op = pop(&stack);
		strcat(out,op);
		strcat(out," ");
	}
	
	return out;
}

int is_operator(char* aux)
{
	if(!strcmp(aux,"+"))
		return 1;
	else if(!strcmp(aux,"-"))
		return 1;
	else if(!strcmp(aux,"*"))
		return 1;
	else if(!strcmp(aux,"/"))
		return 1;
	else if(!strcmp(aux,"^"))
		return 1;
	return 0;
}

double eval(char* in, double x, double y)
{
	stack_t stack;
	double op1,op2,result;
	char* in_aux = (char*)calloc(100,sizeof(char));
	char* op = NULL;
	

	init_stack(&stack);
	
	strcpy(in_aux,in);
	char* aux = strtok(in_aux," ");
	while(aux)
	{

		if(!is_operator(aux))
		{

			push(&stack,aux);
		}
		else
		{

			
			op = pop(&stack);
			if(!strcmp(op,"x"))
				op1 = x;
			else if(!strcmp(op,"y"))
				op1 = y;
			else
				op1 = atof(op);
			
			op = pop(&stack);
			
			if(!strcmp(op,"x"))
				op2 = x;
			else if(!strcmp(op,"y"))
				op2 = y;
			else
				op2 = atof(op);
			
			result = calculate(op1,op2,aux);
			char *result_str = (char*)calloc(10,sizeof(char));
			sprintf(result_str,"%.5f",result);

			push(&stack,result_str);
			free(result_str);
		}
		
		aux = NULL;
		aux = strtok(NULL," ");
	}
	return atof(pop(&stack));
}

double calculate(double x, double y, char *op)
{
	if(!strcmp(op,"+"))
		return (double)x+(double)y;
	else if(!strcmp(op,"-"))
		return (double)y-(double)x;
	else if(!strcmp(op,"*"))
		return (double)x*(double)y;
	else if(!strcmp(op,"/"))
		return (double)y/(double)x;
	else if(!strcmp(op,"^"))
		return (double)pow((double)y,(double)x);
	
	return 0;
}
