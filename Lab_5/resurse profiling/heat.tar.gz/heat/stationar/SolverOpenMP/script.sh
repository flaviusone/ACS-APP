#!/bin/bash
~/implementare/stationar/SolverOpenMP/solver_openmp ~/implementare/stationar/SolverOpenMP/input
