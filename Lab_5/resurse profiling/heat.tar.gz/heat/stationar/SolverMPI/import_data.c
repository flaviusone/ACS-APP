/*
 * File:   import_data.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver (parallel - using MPI)
 */

#include "solver.h"

int import_data_file(char *path)
{
	FILE *f;    

	f = fopen(path,"r");
	if(f == NULL)
	{
		printf("\n[ERROR] IMPORTING DATA FROM FILE FAILED - UNABLE TO OPEN FILE!!!\n");
		return -1;
	}
	else
	{
		char *line = (char*)calloc(256,sizeof(char));
		int aux, scn_index = -1, scn_ok = 0;
		int i;
		
		while(fgets(line,255,f) != NULL)
		{
			char *p = strtok(line," =");
			if(p != NULL)
			{
				if(!strcmp("[NUM_SCENARIO]", p))
				{
					num_scenarios = atoi(strtok(NULL," =\n"));
					//scenario = (scenario_t*)calloc(num_scenarios,sizeof(scenario_t));
				}
				else if(!strcmp("[SCENARIO]", p))
				{
					aux = atoi(strtok(NULL," ="));
					if(aux < num_scenarios && aux >= 0)
					{
					scn_index = aux;
					scn_ok = 1;
					for(i=0;i<3;i++)
					{
						scenario[scn_index].alg[i] = 0;
						scenario[scn_index].time[i] = 0.0;
						scenario[scn_index].OMP_THREADS = 2;
					}
					}
					else
					scn_ok = 0;
				}
				else if(!strcmp("[OMP_THREADS]", p) && scn_ok)
					scenario[scn_index].OMP_THREADS = atoi(strtok(NULL," ="));
				else if(!strcmp("[SIZEX]", p) && scn_ok)
					scenario[scn_index].nx = atoi(strtok(NULL," ="));
				else if(!strcmp("[SIZEY]",p) && scn_ok)
					scenario[scn_index].ny = atoi(strtok(NULL," ="));
				else if(!strcmp("[BETA]",p) && scn_ok)
					scenario[scn_index].beta = atof(strtok(NULL," ="));
				else if(!strcmp("[H]",p) && scn_ok)
					scenario[scn_index].h = atof(strtok(NULL," ="));
				else if(!strcmp("[EPS]",p) && scn_ok)
					scenario[scn_index].EPS = atof(strtok(NULL," ="));
				else if(!strcmp("[MAXITER]",p) && scn_ok)
					scenario[scn_index].MAX_ITER = atoi(strtok(NULL," ="));
				else if(!strcmp("[ALG]",p) && scn_ok)
				{
					p = strtok(NULL," =\n");
					if(!strcmp("M_JACOBI",p))
						scenario[scn_index].alg[M_JACOBI] = 1;
					else if(!strcmp("M_GAUSS_SEIDEL", p))
						scenario[scn_index].alg[M_GAUSS_SEIDEL] = 1;
					else if(!strcmp("M_GAUSS_SEIDEL_RELAX", p))
						scenario[scn_index].alg[M_GAUSS_SEIDEL_RELAX] = 1;
				}
				else if(!strcmp("[SOURCEX]",p) && scn_ok)
						scenario[scn_index].rx  = atof(strtok(NULL, " ="));
				else if(!strcmp("[SOURCEY]",p) && scn_ok)
						scenario[scn_index].ry  = atof(strtok(NULL, " ="));
				else if(!strcmp("[SOURCERADIUS]",p) && scn_ok)
						scenario[scn_index].raza  = atoi(strtok(NULL, " ="));
				else if(!strcmp("[SOURCETEMP]",p) && scn_ok)
						scenario[scn_index].temp  = atof(strtok(NULL, " ="));	
				else if(!strcmp("[FUNC]",p) && scn_ok)
						strcpy(scenario[scn_index].func,strtok(NULL, "=\n"));
			}
		}
		return 0;
	}
}
