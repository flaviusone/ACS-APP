#!/bin/bash
mpirun -np 4 ~/implementare/stationar/SolverMPI/solver_mpi ~/implementare/stationar/SolverMPI/input
