/* 
 * File:   mpi_alg.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver (parallel - using MPI)
 */

#include "solver.h"

double func (int i, int j, char* func_polish)
{
	return (double)eval(func_polish,(double)i/(double)ny,(double)j/(double)nx);
}

void print (double **a, int nx, int ny)
{
    int i,j;
    for(i=0;i<ny;i++)
    {
        for(j=0;j<nx;j++)
           printf("%lf  ",a[i][j]);
        printf("\n");
    }
}

void init()
{
    int i,j;
    double r;

    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    for(i=0;i<ny;i+=1)
    {
        uc[i][0] = ua[i][0] = func(i,0,func_polish);
        uc[i][nx-1] = ua[i][nx-1] = func(i,nx-1,func_polish);
    }

    for(i=0;i<nx;i+=1)
    {
        uc[0][i] = ua[0][i] = func(0,i,func_polish);
        uc[ny-1][i] = ua[ny-1][i] = func(ny-1,i,func_polish);
    }

    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = ua[i][j] = 0;	

    #pragma omp parallel for private(i,j,r)
    for(i=0;i<ny;i++)
        for(j=0;j<nx;j++)
	{
		r = sqrt (pow((j - rx),2) + pow((i - ry),2));
		if ((int)r <= raza)
			q[i][j] = temp;
	}

}

void clear(int ny)
{
    int i,j;

    #pragma omp parallel for private(i,j)
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = 0;
}

double m_jacobi(int ny)
{
	double rez = 9999;
	double maxrez = -1;
	int i,j;
	
	
	#pragma omp parallel for private(i,j,rez)
	for(i=1;i<ny+1;i++)
		for(j=1;j<nx-1;j++)
		{
			uc[i][j] = 0.25 * (q[i][j]*h*h + ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]);
			rez = fabs(ua[i][j]-uc[i][j]);
			if(maxrez < rez) maxrez = rez;
		}
	
	xchg = ua;
	ua = uc;
	uc = xchg;
	
	return maxrez;
}

double m_gauss_seidel(int ny)
{
	double rez = 9999;
	double maxrez = -1;
	double ug;
	int i,j;
	
	
	#pragma omp parallel for private(i,j,rez,ug)
	for(i=1;i<ny+1;i++)
		for(j=1;j<nx-1;j++)
		{
			ug = 0.25 * (q[i][j]*h*h + ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]);
			rez = fabs(ua[i][j]-ug);
			if(maxrez < rez) maxrez = rez;
			ua[i][j] = ug;
		}
	
	return maxrez;
}

double m_gauss_seidel_relax(int ny)
{
	double rez = 9999;
	double maxrez = -1;
	double ug;
	int i,j;
	
	
	#pragma omp parallel for private(i,j,rez,ug)
	for(i=1;i<ny+1;i++)
		for(j=1;j<nx-1;j++)
		{
			ug = 0.25 * (q[i][j]*h*h + ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]);
			rez = fabs(ua[i][j]-ug);
			if(maxrez < rez) maxrez = rez;
			ua[i][j] = (1-beta)*ua[i][j] + beta*ug;
		}
	
	return maxrez;
}
