#!/bin/bash
~/implementare/stationar/Solver/solver ~/implementare/stationar/Solver/input
