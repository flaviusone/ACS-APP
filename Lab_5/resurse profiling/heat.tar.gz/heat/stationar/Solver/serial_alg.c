/* 
 * File:   serial_alg.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

#include "solver.h"

double func (int i, int j, int nx, int ny, char* func_polish)
{
	return (double)eval(func_polish,(double)i/(double)ny,(double)j/(double)nx);
}

void print (double **a, int nx, int ny)
{
    int i,j;
    for(i=0;i<ny;i++)
    {
        for(j=0;j<nx;j++)
           printf("%lf  ",a[i][j]);
        printf("\n");
    }
}

void init(double **uc, double **ua, int nx, int ny, double **q, int rx, int ry, int raza, double temp)
{
    int i,j;
    double r;

    char* func_polish = reverse_polish_notation(scenario[scn_index].func);


    for(i=0;i<ny;i+=1)
    {
        uc[i][0] = ua[i][0] = func(i,0,nx,ny,func_polish);
        uc[i][nx-1] = ua[i][nx-1] = func(i,nx-1,nx,ny,func_polish);
    }
    for(i=0;i<nx;i+=1)
    {
        uc[0][i] = ua[0][i] = func(0,i,nx,ny,func_polish);
        uc[ny-1][i] = ua[ny-1][i] = func(ny-1,i,nx,ny,func_polish);
    }
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = ua[i][j] = 0;	
    for(i=0;i<ny;i++)
        for(j=0;j<nx;j++)
		{
		r = sqrt (pow((j - rx),2) + pow((i - ry),2));
		if ((int)r <= raza)
			q[i][j] = temp;
		}

}

void clear(double **uc, int nx, int ny)
{
    int i,j;
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = 0;
}

double s_jacobi(double **uc, double **ua, double **q, double h, int nx, int ny)
{
    double rez = 9999, maxerr = -1, err, maxrez = EPS;
    double **xchg;
    unsigned int step = 0;
    int i,j;
    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    printf("###################\n");
    printf("## Jacobi serial ##\n");

    time_t start = time(NULL);
    while ((maxrez >= EPS) && (step <= MAX_ITER))
    {
        rez = 9999;
        maxrez = -1;
        for(i=1;i<ny-1;i++)
            for(j=1;j<nx-1;j++)
                {
                    uc[i][j] = 0.25 * (q[i][j]*h*h + ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]);
                    rez = fabs(ua[i][j]-uc[i][j]);
                    if(maxrez < rez) maxrez = rez;
                }

        xchg = ua;
        ua = uc;
        uc = xchg;

        step++;
    }
    time_t stop = time(NULL);

    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
        {
            err = fabs(ua[i][j]-func(i,j,nx,ny,func_polish));
            if (err>maxerr)
                maxerr=err;            
        }

    printf("Reziduu final:       %.15lf\n",maxrez);
    printf("Numar de iteratii:   %d\n",step);
    printf("Timp de lucru:       %.0lf sec\n",difftime(stop,start));
    printf("Eroare maxima:       %.15lf\n",maxerr);
    printf("#######################################\n");

    return difftime(stop,start);
}



double s_gauss_seidel(double **uc, double **q, double h, int nx, int ny)
{
    double rez = 9999, maxerr = -1, err, maxrez = EPS, ug;
    unsigned int step = 0;
    int i,j;
    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    printf("#########################\n");
    printf("## Gauss-Seidel serial ##\n");

    time_t start = time(NULL);
    while ((maxrez >= EPS) && (step <= MAX_ITER))
    {
        rez = 9999;
        maxrez = -1;
        for(i=1;i<ny-1;i++)
            for(j=1;j<nx-1;j++)
                {
                    ug = 0.25 * (q[i][j]*h*h + uc[i-1][j] + uc[i][j-1] + uc[i+1][j] + uc[i][j+1]);
                    rez = fabs(uc[i][j]-ug);
                    if(maxrez < rez) maxrez = rez;
                    uc[i][j] = ug;
                }
        step++;
    }
    time_t stop = time(NULL);

    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
        {
            err = fabs(uc[i][j]-func(i,j,nx,ny,func_polish));
            if(err>maxerr)
                maxerr = err;
        }

    printf("Reziduu final:       %.15lf\n",maxrez);
    printf("Numar de iteratii:   %d\n",step);
    printf("Timp de lucru:       %.0lf sec\n",difftime(stop,start));
    printf("Eroare maxima:       %.15lf\n",maxerr);
    printf("#######################################\n");

    return difftime(stop,start);
}



double s_gauss_seidel_relax(double **uc, double beta, double **q, double h, int nx, int ny)
{
    double rez = 9999, maxerr = -1, err, maxrez = EPS, ug;
    unsigned int step = 0;
    int i,j;
    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    printf("######################################\n");
    printf("## Gauss-Seidel over-relaxed serial ##\n");

    time_t start = time(NULL);
    while ((maxrez >= EPS) && (step <= MAX_ITER))
    {
        rez = 9999;
        maxrez = -1;
        for(i=1;i<ny-1;i++)
            for(j=1;j<nx-1;j++)
                {
                    ug = 0.25 * (q[i][j]*h*h + uc[i-1][j] + uc[i][j-1] + uc[i+1][j] + uc[i][j+1]);
                    rez = fabs(uc[i][j]-ug);
                    if(maxrez < rez) maxrez = rez;
                    uc[i][j] = (1-beta)*uc[i][j] + beta*ug;
                }
        step++;
    }
    time_t stop = time(NULL);

    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
        {
            err = fabs(uc[i][j]-func(i,j,nx,ny,func_polish));
            if(err>maxerr)
                maxerr = err;            
        }

    printf("Reziduu final:       %.15lf\n",maxrez);
    printf("Numar de iteratii:   %d\n",step);   
    printf("Timp de lucru:       %.0lf sec\n",difftime(stop,start));
    printf("Eroare maxima:       %.15lf\n",maxerr);
    printf("#######################################\n");

    return difftime(stop,start);
}




