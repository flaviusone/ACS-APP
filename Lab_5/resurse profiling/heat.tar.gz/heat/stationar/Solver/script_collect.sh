#!/bin/bash
collect ~/implementare/stationar/Solver/solver ~/implementare/stationar/Solver/input1
