#!/bin/bash
collect ~/implementare/nestationar/Solver/solver ~/implementare/nestationar/Solver/input1
