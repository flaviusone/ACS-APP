#!/bin/bash
~/implementare/nestationar/Solver/solver ~/implementare/nestationar/Solver/input
