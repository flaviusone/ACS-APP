#!/bin/bash
mpirun -np 4 ~/implementare/nestationar/SolverMPI/solver_mpi ~/implementare/nestationar/SolverMPI/input
