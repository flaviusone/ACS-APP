/* 
 * File:   main.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver (parallel - using MPI)
 */

#include "solver.h" 


int main(int argc, char** argv)
{
	// Variable declarations
	int i, j;
	int numtask, rank, err;
	MPI_Status status;
	MPI_Datatype MPI_SCENARIO, oldtypes[3];
	MPI_Aint offsets[3], extent;
	int blockcounts[3];
	time_t start = 0;

	
	
	err = MPI_Init(&argc,&argv);
	if (err != MPI_SUCCESS) 
	{
		printf ("Error starting MPI program. Terminating.\n");
		MPI_Abort(MPI_COMM_WORLD, err);
	}

	MPI_Comm_size(MPI_COMM_WORLD,&numtask);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	if(rank == 0)
	{
		printf("%d tasks started\n",numtask);
		
	}

	offsets[0] = 0;
	oldtypes[0] = MPI_INT;
	blockcounts[0] = 4;
	
	MPI_Type_extent(MPI_INT,&extent);
	offsets[1] = 4*extent;
	oldtypes[1] = MPI_DOUBLE;
	blockcounts[1] = 8;
	
	MPI_Type_extent(MPI_DOUBLE,&extent);
	offsets[2] = offsets[1] + 8*extent;
	oldtypes[2] = MPI_CHAR;
	blockcounts[2] = 100;
	
	MPI_Type_struct(3,blockcounts,offsets,oldtypes,&MPI_SCENARIO);
	MPI_Type_commit(&MPI_SCENARIO);

	MPI_Barrier(MPI_COMM_WORLD);
	scn_index = 0;
	if(rank == 0)
	{
		if(argc != 2)
		{
			printf("[ERROR] Usage: %s <input_filename>\n",argv[0]);
			exit(-1);
		}

		err = import_data_file(argv[1]);
		if(err == -1)
		{
			MPI_Abort(MPI_COMM_WORLD,0);
		}
		
		//printf("[%d]	:::Scenario(s) loaded:::\n",rank);
		//printf("[%d]	%d loaded (%d %d)\n",rank,num_scenarios,scenario[0].nx,scenario[0].ny);
		
		for(i=1;i<numtask;i++)
		MPI_Send(&num_scenarios,1,MPI_INT,i,1,MPI_COMM_WORLD);
	}
	else
		MPI_Recv(&num_scenarios,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
	
	if(rank == 0)
		for(i=1;i<numtask;i++)
			MPI_Send(&scenario,num_scenarios,MPI_SCENARIO,i,1,MPI_COMM_WORLD);
	else
		MPI_Recv(&scenario,num_scenarios,MPI_SCENARIO,0,1,MPI_COMM_WORLD,&status);
	
	scn_index = 0;
	while(scn_index < num_scenarios)
	{
		omp_set_num_threads(scenario[scn_index].OMP_THREADS);
		ny = scenario[scn_index].ny;
		nx = scenario[scn_index].nx;
		h = scenario[scn_index].h;
		w = scenario[scn_index].w;
		step = scenario[scn_index].step;
		MAX_TIME = scenario[scn_index].MAX_TIME;
		TIME_SLICE = scenario[scn_index].TIME_SLICE;
		rx = (int)(scenario[scn_index].rx*nx);
		ry = (int)(scenario[scn_index].ry*ny);
		raza = scenario[scn_index].raza;
		temp = scenario[scn_index].temp;
		start = time(NULL);		

		int local_ny;
		
		if(rank == 0)
		{
			// Allocating arrays
			ua =  (double**) calloc (ny, sizeof(double*));
			uc =  (double**) calloc (ny, sizeof(double*));
			q  =  (double**) calloc (ny, sizeof(double*));
			for(i=0;i<ny;i+=1)
			{
				ua[i] = (double*) calloc (nx, sizeof(double));
				uc[i] = (double*) calloc (nx, sizeof(double));
				q[i]  = (double*) calloc (nx, sizeof(double));
			}
			
			local_ny = ny/numtask;
			
			init();
			
			export_to_vtk(ua,nx,ny,scn_index,0);
			
			for(i=1;i<numtask-1;i++)
			{
				//printf("[%d]	Sending to rank %d, %d rows\n",rank,i,ny/numtask);
				for(j=i*(ny/numtask);j<(i+1)*(ny/numtask);j++)
				{
					MPI_Send(q[j],nx,MPI_DOUBLE,i,1,MPI_COMM_WORLD);
					MPI_Send(ua[j],nx,MPI_DOUBLE,i,2,MPI_COMM_WORLD);
				}
			}
			//printf("[%d]	Sending to rank %d, %d rows\n",rank,numtask-1,ny-(numtask-1)*ny/numtask);
			for(j=(numtask-1)*(ny/numtask);j<ny;j++)
			{
				MPI_Send(q[j],nx,MPI_DOUBLE,numtask-1,1,MPI_COMM_WORLD);
				MPI_Send(ua[j],nx,MPI_DOUBLE,numtask-1,2,MPI_COMM_WORLD);
			}
		}
		else
		{
			if(rank != numtask-1)
			{
				// Allocating arrays
				ua =  (double**) calloc (ny/numtask+2, sizeof(double*));
				uc =  (double**) calloc (ny/numtask+2, sizeof(double*));
				q  =  (double**) calloc (ny/numtask+2, sizeof(double*));
				for(i=0;i<ny/numtask+2;i++)
				{
					ua[i] = (double*) calloc (nx, sizeof(double));
					uc[i] = (double*) calloc (nx, sizeof(double));
					q[i]  = (double*) calloc (nx, sizeof(double));
				}
				
				local_ny = ny/numtask;
				
				// Receiving arrays
				for(i=1;i<local_ny+1;i++)
				{
					MPI_Recv(q[i],nx,MPI_DOUBLE,0,1,MPI_COMM_WORLD,&status);
					MPI_Recv(ua[i],nx,MPI_DOUBLE,0,2,MPI_COMM_WORLD,&status);
				}

			}
			else
			{
				// Allocating arrays
				int rest = ny - (numtask-1)*(ny/numtask);
				ua =  (double**) calloc (rest+1, sizeof(double*));
				uc =  (double**) calloc (rest+1, sizeof(double*));
				q  =  (double**) calloc (rest+1, sizeof(double*));
				for(i=0;i<rest+1;i++)
				{
					ua[i] = (double*) calloc (nx, sizeof(double));
					uc[i] = (double*) calloc (nx, sizeof(double));
					q[i]  = (double*) calloc (nx, sizeof(double));
				}
				
				local_ny = rest;
				
				// Receiving arrays
				for(i=1;i<local_ny+1;i++)
				{
					MPI_Recv(q[i],nx,MPI_DOUBLE,0,1,MPI_COMM_WORLD,&status);
					MPI_Recv(ua[i],nx,MPI_DOUBLE,0,2,MPI_COMM_WORLD,&status);
				}
				
				for(i=0;i<nx;i++)
					uc[local_ny][i] = ua[local_ny][i];
			}
		}
		
		for(i=0;i<local_ny+2;i++)
		{
			if(rank == numtask-1 && i == local_ny+1) break;
			uc[i][0] = ua[i][0];
			uc[i][nx-1] = ua[i][nx-1];
		}
		
		
		if(rank == 0)
		{
			int save_step = 0, done = 0, count = 0;
			int MAX_ITER = (int)(scenario[scn_index].MAX_TIME/scenario[scn_index].TIME_SLICE);
			
			while(count < MAX_ITER)
			{
				m_mdf(local_ny);
				
				if(count%scenario[scn_index].step == 0)
					save_step = 1;
				else
					save_step = 0;
				
				for(i=1;i<numtask;i++)
				{
						MPI_Send(&done,1,MPI_INT,i,1,MPI_COMM_WORLD);
						MPI_Send(&save_step,1,MPI_INT,i,1,MPI_COMM_WORLD);
						
						if(save_step == 1)
						{
							if(i != numtask-1)
								for(j=0;j<ny/numtask;j++)
									MPI_Recv(ua[i*(ny/numtask)+j],nx,MPI_DOUBLE,i,1,MPI_COMM_WORLD,&status);
							if(i == numtask-1)
								for(j=i*(ny/numtask);j<ny;j++)
									MPI_Recv(ua[j],nx,MPI_DOUBLE,i,1,MPI_COMM_WORLD,&status);
						}
				}
				if(save_step == 1)
					export_to_vtk(ua,nx,ny,scn_index,count);
				
				
				MPI_Recv(ua[local_ny+1],nx,MPI_DOUBLE,1,1,MPI_COMM_WORLD,&status);
				MPI_Send(ua[local_ny],nx,MPI_DOUBLE,1,1,MPI_COMM_WORLD);
				
				count++;
			}
			
			save_step = 1;	
			done = 1;
			for(i=1;i<numtask;i++)
			{
				MPI_Send(&done,1,MPI_INT,i,1,MPI_COMM_WORLD);
				MPI_Send(&save_step,1,MPI_INT,i,1,MPI_COMM_WORLD);
			}
		
			
			for(i=1;i<numtask;i++)
			{
				if(i != numtask-1)
					for(j=0;j<ny/numtask;j++)
						MPI_Recv(ua[i*(ny/numtask)+j],nx,MPI_DOUBLE,i,1,MPI_COMM_WORLD,&status);
				if(i == numtask-1)
					for(j=i*(ny/numtask);j<ny;j++)
						MPI_Recv(ua[j],nx,MPI_DOUBLE,i,1,MPI_COMM_WORLD,&status);
			}
			
			export_to_vtk(ua,nx,ny,scn_index,MAX_ITER);
		}
		else
		{
			int done = 0, save_step = 0;
			
			while(!done)
			{
				if(rank != numtask-1)
					m_mdf(local_ny);
				else
					m_mdf(local_ny-1);
				
				MPI_Recv(&done,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
				MPI_Recv(&save_step,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
				
				if(save_step == 1)
					for(i=1;i<local_ny+1;i++)
						MPI_Send(ua[i],nx,MPI_DOUBLE,0,1,MPI_COMM_WORLD);
				
				if(done == 0)
				{
					if(rank%2 == 1 && rank != numtask-1)
					{
						MPI_Send(ua[1],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD);
						MPI_Recv(ua[0],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD,&status);
						MPI_Send(ua[local_ny],nx,MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD);
						MPI_Recv(ua[local_ny+1],nx,MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD,&status);
					}
					else if(rank%2 == 0 && rank != numtask-1)
					{
						MPI_Recv(ua[local_ny+1],nx,MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD,&status);
						MPI_Send(ua[local_ny],nx,MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD);
						MPI_Recv(ua[0],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD,&status);
						MPI_Send(ua[1],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD);
					}
					else if(rank == numtask-1)
					{
						MPI_Send(ua[1],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD);
						MPI_Recv(ua[0],nx,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD,&status);
					}
				}
			}
		}
		
		if(rank == 0)
		{
			time_t stop = time(NULL);
			scenario[scn_index].time = difftime(stop,start);
			export_to_gnuplot(scn_index);
		}
		
		MPI_Barrier(MPI_COMM_WORLD);
		
		scn_index++;
	}
	
	MPI_Type_free(&MPI_SCENARIO);

	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();

	return 0;
}

