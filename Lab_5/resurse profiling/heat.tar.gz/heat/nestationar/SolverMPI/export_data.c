/* 
 * File:   export_data.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

 
#include "solver.h"

int export_to_vtk(double **mat, int nx, int ny, int scn_index, int step)
{
    FILE *f;
    char *path,*buf;

    path = (char*)calloc(256,sizeof(char));
    buf = (char*)calloc(256,sizeof(char));

    getcwd(buf,255);

    sprintf(path,"%s/export/m_mdf[scn%d]_step%d.vtk",buf,scn_index,step);


    f = fopen(path,"w");
    if(f == NULL)
    {
        printf("\n[ERROR] EXPORTING DATA TO .VTK FILE FORMAT FAILED - UNABLE TO OPEN SAVEFILE!!!\n");
        free(path);
        free(buf);
        return -1;
    }
    else
    {
        long int i,j;
        fprintf(f,"# vtk DataFile Version 2.0\n");
        fprintf(f,"This is a test file for the vtk format file export\n");
        fprintf(f,"ASCII\n");
        fprintf(f,"DATASET UNSTRUCTURED_GRID\n\n");
        fprintf(f,"POINTS %d double\n",(nx+1)*(ny+1));
        for(i=0;i<ny+1;i++)
            for(j=0;j<nx+1;j++)
                fprintf(f,"%.20lf %.20lf %.20lf\n",(double)i/(double)ny,(double)j/(double)nx,0.0);
        fprintf(f,"\nCELLS %d %d\n",nx*ny,5*(nx*ny));
        for(i=0;i<ny;i++)
            for(j=0;j<nx;j++)
                fprintf(f,"4  %ld  %ld  %ld  %ld\n",j+i*nx+i,j+i*nx+i+1,j+(i+1)*nx+i+2,j+(i+1)*nx+i+1);
        fprintf(f,"\nCELL_TYPES   %d\n",nx*ny);
        for(i=0;i<ny*nx;i++)
            fprintf(f,"9 ");
        fprintf(f,"\nCELL_DATA   %d\n",(nx)*(ny));
        fprintf(f,"SCALARS u FLOAT\n");
        fprintf(f,"LOOKUP_TABLE values_table\n");
        for(i=0;i<ny;i++)
            for(j=0;j<nx;j++)
                fprintf(f,"%.20lf\n",mat[i][j]);

        fclose(f);
    }

    free(path);
    free(buf);
    return 0;
}



int export_to_gnuplot( int scn_index)
{
    FILE *f;
    double cells = scenario[scn_index].nx * scenario[scn_index].ny;
    double time = scenario[scn_index].time;

    char *path,*buf;

    path = (char*)calloc(256,sizeof(char));
    buf = (char*)calloc(256,sizeof(char));
    getcwd(buf,255);

    sprintf(path,"%s/export/m_mdf.dat",buf);


    f = fopen(path,"a");
    if(f == NULL)
    {
        printf("\n[ERROR] EXPORTING DATA TO .DAT FILE FORMAT FAILED - UNABLE TO OPEN SAVEFILE!!!\n");
        return -1;
    }
    else
    {
        fprintf(f,"%f   %f\n",cells,time);
        fclose(f);
        return 0;
    }
}
