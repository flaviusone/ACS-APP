/* 
 * File:   solver.h
 * Author: Ana-Maria Tuleiu
 *
 * Created on July 19, 2008, 3:25 AM
 */

#ifndef _SOLVER_H
#define	_SOLVER_H
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>

#include <mpi.h>
#include <omp.h>

#define MAX_STACK_SIZE 100


typedef struct scn
{
    int OMP_THREADS;
    int nx;
    int ny;
    int raza;
    int step;
    double rx;
    double ry;
    double temp;
    double h;
    double w;
    double time;
    double MAX_TIME;
    double TIME_SLICE;
    char func[100];
} scenario_t;

typedef struct 
{
    char st[MAX_STACK_SIZE][10];
    int sp;
} stack_t;

// Global variables
scenario_t scenario[10];
int num_scenarios, scn_index,step;
double h, MAX_TIME, TIME_SLICE, w, temp;
int nx, ny, raza,rx, ry;
double **ua , **uc, **q, **xchg;

// General use functions
double func (int i, int j, char* func_polish);
void print_mat(double **a, int nx, int ny);
void init();
void clear(int ny);

// Import functions (data)
int import_data_file(char *path);

// Export functions (data & results)
int export_to_vtk(double **mat, int nx, int ny, int scn_index, int step);
int export_to_gnuplot(int scn_index);

//Algorithm
void m_mdf(int ny);


// Arithmetic expressions evaluation functions (for input data)
void init_stack(stack_t* stack);
int empty_stack(stack_t stack);
void push(stack_t* stack, char* x);
char* pop(stack_t* stack);
char* top(stack_t* stack);
char* reverse_polish_notation(char* in);
int priority(char* op);
double eval (char* in, double x, double y);
double calculate(double x, double y, char* op);
int is_operator(char* aux);

