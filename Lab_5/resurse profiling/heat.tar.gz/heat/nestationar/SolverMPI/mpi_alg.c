/* 
 * File:   mpi_alg.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver (parallel - using MPI)
 */

#include "solver.h"

double func (int i, int j, char* func_polish)
{
	return (double)eval(func_polish,(double)i/(double)ny,(double)j/(double)nx);
}

void print (double **a, int nx, int ny)
{
    int i,j;
    for(i=0;i<ny;i++)
    {
        for(j=0;j<nx;j++)
           printf("%lf  ",a[i][j]);
        printf("\n");
    }
}

void init()
{
    int i,j;
    double r;

    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    #pragma omp parallel for private(i) schedule(static)
    for(i=0;i<ny;i+=1)
    {
        uc[i][0] = ua[i][0] = func(i,0,func_polish);
        uc[i][nx-1] = ua[i][nx-1] = func(i,nx-1,func_polish);
    }

    #pragma omp parallel for private(i) schedule(static)
    for(i=0;i<nx;i+=1)
    {
        uc[0][i] = ua[0][i] = func(0,i,func_polish);
        uc[ny-1][i] = ua[ny-1][i] = func(ny-1,i,func_polish);
    }

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = ua[i][j] = 0;	

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=0;i<ny;i++)
        for(j=0;j<nx;j++)
	{
		r = sqrt (pow((j - rx),2) + pow((i - ry),2));
		if ((int)r <= raza)
			q[i][j] = temp;
	}

}

void clear(int ny)
{
    int i,j;

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = 0;
}

void m_mdf(int ny)
{
	
	int i,j;
	
	#pragma omp parallel for private(i,j) schedule(static)
	for(i=1;i<ny+1;i++)
		for(j=1;j<nx-1;j++)
			uc[i][j] = (1 - 4*h*w*TIME_SLICE)*ua[i][j] + h*w*TIME_SLICE*(ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]) + w*TIME_SLICE*q[i][j];
	
		xchg = ua;
		ua = uc;
		uc = xchg;
}
