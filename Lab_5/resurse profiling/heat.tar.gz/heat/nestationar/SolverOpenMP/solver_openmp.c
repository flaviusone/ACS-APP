/* 
 * File:   main.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

#include "solver.h"

int main(int argc, char** argv) 
{
    if(argc != 2)
    {
        printf("[ERROR] Usage: %s <input_filename>\n",argv[0]);
        exit(-1);
    }

    // Variable declarations
    int i, rx, ry, raza;
    double **ua , **uc, **q;
    double temp;

    if(import_data_file(argv[1]) == -1)
    {
        exit(-1);
    }

    printf(":::Scenario(s) loaded:::\n");
    printf("%d loaded\n",num_scenarios);

    // Running scenarios
    scn_index = 0;
    while(scn_index < num_scenarios)
    {
        omp_set_num_threads(scenario[scn_index].OMP_THREADS);
        nx = scenario[scn_index].nx;
        ny = scenario[scn_index].ny;
        step = scenario[scn_index].step;
        h = scenario[scn_index].h;
	w = scenario[scn_index].w;
        TIME_SLICE = scenario[scn_index].TIME_SLICE;
        MAX_TIME = scenario[scn_index].MAX_TIME;
	rx = (int)(scenario[scn_index].rx*nx);
	ry = (int)(scenario[scn_index].ry*ny);
	raza = scenario[scn_index].raza;
	temp = scenario[scn_index].temp;

        printf("\n:::Running scenario no. %d:::\n",scn_index);
        printf("Size: [%d x %d]\n",nx,ny);

        // Allocating arrays
        ua =  (double**) calloc (ny, sizeof(double*));
        uc =  (double**) calloc (ny, sizeof(double*));
        q  =  (double**) calloc (ny, sizeof(double*));
        for(i=0;i<ny;i+=1)
        {
            ua[i] = (double*) calloc (nx, sizeof(double));
            uc[i] = (double*) calloc (nx, sizeof(double));
            q[i]  = (double*) calloc (nx, sizeof(double));
        }


        init(uc,ua,nx,ny,q,rx,ry,raza,temp);

	clear(uc,nx,ny);
	scenario[scn_index].time = p_mdf(uc,ua,q,h,w,nx,ny);
	export_to_vtk(uc,nx,ny,scn_index,(int)(MAX_TIME/TIME_SLICE));
	fflush(stdout);


        free(uc);
        free(ua);
        free(q);

        scn_index++;
    }

    /*
    // The scenarios will be sorted by dimension (cells) for easier data manipulation
    if(num_scenarios > 1)
    {
        scenario_t xchg;
        for(i=0;i<num_scenarios-1;i++)
        {
            min = scenario[i].nx*scenario[i].ny;
            for(j=i+1;j<num_scenarios;j++)
                if(scenario[j].nx*scenario[j].ny < min)
                {
                    min = scenario[j].nx*scenario[j].ny;
                    xchg = scenario[j];
                    scenario[j] = scenario[i];
                    scenario[i] = xchg;
                }
        }
    }
    */


    //Export date pentru GNUPLOT
    printf(":::Exporting results:::\nFormat for GNUPLOT\n");
    for(i=0;i<num_scenarios;i++)
          export_to_gnuplot(i);

    return (EXIT_SUCCESS);
}

		
