/* 
 * File:   serial_alg.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

#include "solver.h"

double func (int i, int j, int nx, int ny, char* func_polish)
{
	return (double)eval(func_polish,(double)i/(double)ny,(double)j/(double)nx);
}

void print (double **a, int nx, int ny)
{
    int i,j;
    for(i=0;i<ny;i++)
    {
        for(j=0;j<nx;j++)
           printf("%lf  ",a[i][j]);
        printf("\n");
    }
}

void init(double **uc, double **ua, int nx, int ny, double **q, int rx, int ry, int raza, double temp)
{
    int i,j;
    double r;

    char* func_polish = reverse_polish_notation(scenario[scn_index].func);

    #pragma omp parallel for private(i) schedule(static)
    for(i=0;i<ny;i+=1)
    {
        uc[i][0] = ua[i][0] = func(i,0,nx,ny,func_polish);
        uc[i][nx-1] = ua[i][nx-1] = func(i,nx-1,nx,ny,func_polish);
    }

    #pragma omp parallel for private(i) schedule(static)
    for(i=0;i<nx;i+=1)
    {
        uc[0][i] = ua[0][i] = func(0,i,nx,ny,func_polish);
        uc[ny-1][i] = ua[ny-1][i] = func(ny-1,i,nx,ny,func_polish);
    }

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = ua[i][j] = 0;	

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=0;i<ny;i++)
        for(j=0;j<nx;j++)
		{
		r = sqrt (pow((j - rx),2) + pow((i - ry),2));
		if ((int)r <= raza)
			q[i][j] = temp;
		}

}

void clear(double **uc, int nx, int ny)
{
    int i,j;

    #pragma omp parallel for private(i,j) schedule(static)
    for(i=1;i<ny-1;i++)
        for(j=1;j<nx-1;j++)
            uc[i][j] = 0;
}

double p_mdf(double **uc, double **ua, double **q, double h, double w, int nx, int ny)
{

    double **xchg;
    double t = (double)scenario[scn_index].TIME_SLICE;
    int count = 0;
    int i,j;
    double MAX_ITER = (double)scenario[scn_index].MAX_TIME / (double)t;

    printf("###################\n");

    time_t start = time(NULL);
    while (count <= MAX_ITER)
    {
	#pragma omp parallel for private(i,j) schedule(static)
        for(i=1;i<ny-1;i++)
            for(j=1;j<nx-1;j++)
                    uc[i][j] = (1 - 4*h*w*t)*ua[i][j] + h*w*t*(ua[i-1][j] + ua[i][j-1] + ua[i+1][j] + ua[i][j+1]) + w*t*q[i][j];

        xchg = ua;
        ua = uc;
        uc = xchg;
	
	if(count%(scenario[scn_index].step) == 0)
		export_to_vtk(uc,nx,ny,scn_index,count);

        count++;
    }
    time_t stop = time(NULL);

    return difftime(stop,start);
}







