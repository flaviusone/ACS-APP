/*
 * File:   import_data.c
 * Author: Ana-Maria Tuleiu
 *
 * Laplace solver
 */

#include "solver.h"

int import_data_file(char *path)
{
    FILE *f;    
    
    f = fopen(path,"r");
    if(f == NULL)
    {
        printf("\n[ERROR] IMPORTING DATA FROM FILE FAILED - UNABLE TO OPEN FILE!!!\n");
        return -1;
    }
    else
    {
        char *line = (char*)calloc(256,sizeof(char));
        int aux, scn_index = -1, scn_ok = 0;


        while(fgets(line,256,f) != NULL)
        {
            char *p = strtok(line," =");
            if(p != NULL)
            {
                if(!strcmp("[NUM_SCENARIO]", p))
                {
                    num_scenarios = atoi(strtok(NULL," =\n"));
                    scenario = (scenario_t*)calloc(num_scenarios,sizeof(scenario_t));
                }
                else if(!strcmp("[SCENARIO]", p))
                {
                    aux = atoi(strtok(NULL," ="));
                    if(aux < num_scenarios && aux >= 0)
                    {
                        scn_index = aux;
                        scn_ok = 1;
                        scenario[scn_index].time=0.0;
                        scenario[scn_index].OMP_THREADS = 2;
                    }
                    else
                        scn_ok = 0;
                }
                else if(!strcmp("[OMP_THREADS]", p) && scn_ok)
                    scenario[scn_index].OMP_THREADS = atoi(strtok(NULL," ="));
                else if(!strcmp("[SIZEX]", p) && scn_ok)
                    scenario[scn_index].nx = atoi(strtok(NULL," ="));
                else if(!strcmp("[SIZEY]",p) && scn_ok)
                    scenario[scn_index].ny = atoi(strtok(NULL," ="));
                else if(!strcmp("[MAX_TIME]",p) && scn_ok)
                    scenario[scn_index].MAX_TIME = atof(strtok(NULL," ="));
                else if(!strcmp("[H]",p) && scn_ok)
                    scenario[scn_index].h = atof(strtok(NULL," ="));
		else if(!strcmp("[W]",p) && scn_ok)
                    scenario[scn_index].w = atof(strtok(NULL," ="));
                else if(!strcmp("[TIME_SLICE]",p) && scn_ok)
                    scenario[scn_index].TIME_SLICE = atof(strtok(NULL," ="));
                else if(!strcmp("[STEP]",p) && scn_ok)
                    scenario[scn_index].step = atoi(strtok(NULL," ="));
		else if(!strcmp("[SOURCEX]",p) && scn_ok)
		    scenario[scn_index].rx  = atof(strtok(NULL, " ="));
		else if(!strcmp("[SOURCEY]",p) && scn_ok)
		    scenario[scn_index].ry  = atof(strtok(NULL, " ="));
		else if(!strcmp("[SOURCERADIUS]",p) && scn_ok)
		    scenario[scn_index].raza  = atoi(strtok(NULL, " ="));
		else if(!strcmp("[SOURCETEMP]",p) && scn_ok)
		    scenario[scn_index].temp  = atof(strtok(NULL, " ="));	
		else if(!strcmp("[FUNC]",p) && scn_ok)
		    strcpy(scenario[scn_index].func,strtok(NULL, "=\n"));		
            }
        }
        free(line);
        return 0;
    }
}
