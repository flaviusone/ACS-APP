#!/bin/bash
~/implementare/nestationar/SolverOpenMP/solver_openmp ~/implementare/nestationar/SolverOpenMP/input
