#!/bin/bash
collect mpirun -np 4 ~/implementare/mpi/acoustics ~/implementare/mpi/input
