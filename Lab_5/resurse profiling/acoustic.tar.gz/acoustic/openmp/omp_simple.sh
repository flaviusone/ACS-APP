#!/bin/bash
~/implementare/openmp/acoustics ~/implementare/openmp/input
