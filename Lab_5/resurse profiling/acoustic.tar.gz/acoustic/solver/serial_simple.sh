#!/bin/bash
~/implementare/serial/acoustics ~/implementare/serial/input
