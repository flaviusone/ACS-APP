#!/bin/bash
collect ~/implementare/serial/acoustics ~/implementare/serial/input
